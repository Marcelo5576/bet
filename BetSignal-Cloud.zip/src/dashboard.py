from __future__ import annotations

from collections import Counter, defaultdict
import html
import os
import re
import secrets
from typing import Any

import httpx
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi import Request
from pydantic import BaseModel
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials

from src.config import load_settings
from src.integrations.supabase import SupabaseSink
from src.intelligence.learning import summarize_history
from src.intelligence.manual_import import parse_manual_bets
from src.intelligence.paper_trading import best_paper_entry, paper_opportunities
from src.intelligence.source_catalog import FOOTBALL_DATA_SOURCES
from src.storage import StateStore

app = FastAPI(title="BetSignal Cloud Dashboard")
security = HTTPBasic()


class ImportPayload(BaseModel):
    text: str


class HistoryValuePayload(BaseModel):
    signal_id: str
    entry_value: float | None = None
    entry_odds: float | None = None
    profit_value: float | None = None


class HistoryDeletePayload(BaseModel):
    signal_id: str


class HistoryOutcomePayload(BaseModel):
    signal_id: str
    outcome: str


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; "
        "connect-src 'self'; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self'"
    )
    return response


def _auth(credentials: HTTPBasicCredentials = Depends(security)) -> None:
    settings = load_settings()
    user_ok = secrets.compare_digest(credentials.username, settings.dashboard_user)
    password_ok = secrets.compare_digest(
        credentials.password, settings.dashboard_password
    )
    if not user_ok or not password_ok:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais invalidas",
            headers={"WWW-Authenticate": "Basic"},
        )


@app.get("/", response_class=HTMLResponse)
def dashboard(_: None = Depends(_auth)) -> str:
    settings = load_settings()
    state = StateStore(os.getenv("STATE_FILE", "data/state.json")).load()
    history = state.history or []
    visible_history = _green_red(history)
    scanner = _scanner_status(state)
    stats = _stats(visible_history)
    rows = "\n".join(_row(item) for item in visible_history[:120])
    active_entries = _active_entries(history, state.active_signal)
    active_entry_rows = "\n".join(_active_entry_row(item) for item in active_entries)
    simulation_signals = _simulation_signals(state)
    opportunities = paper_opportunities(simulation_signals)
    simulation_rows = "\n".join(_simulation_row(item) for item in opportunities)
    thermometer_rows = _thermometer_rows(opportunities)
    default_signal = simulation_signals[0] if simulation_signals else None
    match_stats = _match_stats_panel(default_signal, visible_history)
    best_simulation = _best_simulation(best_paper_entry(simulation_signals))
    simulator_updated_at = _short_datetime(state.last_scan_at)
    active = _active(state.active_signal)
    advice = _advice(visible_history)
    learning = summarize_history(visible_history)
    backtest = learning.get("backtest") or {}
    fast_learning = learning.get("fast_learning") or {}
    rankings = _rankings(learning)
    fast_panel = _fast_learning_panel(fast_learning)
    manual_stats = _manual_stats(visible_history)
    supabase_info = _supabase_info(settings)
    source_panel = _source_catalog_panel()
    commercial_panel = _commercial_panel(settings)
    domains = _domains(settings.dashboard_domains)
    support = _esc(settings.support_note)
    product_name = _esc(settings.product_name)
    product_tagline = _esc(settings.product_tagline)
    return f"""<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{product_name}</title>
  <style>
    :root {{
      color-scheme: dark;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      --bg: #0b0e11;
      --panel: #181a20;
      --panel-2: #1e2329;
      --line: #2b3139;
      --text: #eaecef;
      --muted: #848e9c;
      --green: #0ecb81;
      --red: #f6465d;
      --amber: #fcd535;
      --cyan: #4cc9f0;
      --blue: #5b8cff;
      --purple: #9b8cff;
    }}
    * {{ box-sizing: border-box; }}
    html {{ scroll-behavior: smooth; }}
    body {{
      margin: 0;
      background: var(--bg);
      color: var(--text);
    }}
    header {{
      border-bottom: 1px solid var(--line);
      background: #111318;
      position: sticky;
      top: 0;
      z-index: 2;
    }}
    .topbar {{
      align-items: center;
      display: flex;
      justify-content: space-between;
      gap: 16px;
      margin: 0 auto;
      min-height: 58px;
      padding: 10px 18px;
    }}
    h1 {{ margin: 0; font-size: 22px; letter-spacing: 0; color: var(--amber); }}
    h1::before {{ content: "◆"; margin-right: 8px; }}
    h2 {{ font-size: 13px; margin: 0 0 10px; text-transform: none; color: #f5f6f7; }}
    strong, td, th, .metric {{ overflow-wrap: anywhere; }}
    main {{ padding: 8px; max-width: none; margin: 0; }}
    .ticker {{
      display: flex;
      gap: 18px;
      overflow-x: auto;
      padding: 7px 18px;
      border-top: 1px solid #1f242d;
      background: #0f1217;
      color: var(--muted);
      font-size: 12px;
      white-space: nowrap;
    }}
    .ticker span {{ color: var(--green); font-weight: 700; }}
    .app-shell {{ display: grid; grid-template-columns: 190px minmax(0, 1fr); min-height: calc(100vh - 90px); }}
    .sidebar {{
      border-right: 1px solid var(--line);
      background: #0f1217;
      padding: 14px 10px;
    }}
    .mobile-nav {{
      display: none;
      gap: 8px;
      overflow-x: auto;
      padding: 10px 16px;
      border-bottom: 1px solid var(--line);
      background: #111318;
      position: sticky;
      top: 78px;
      z-index: 1;
    }}
    .nav-title {{ color: var(--muted); font-size: 11px; font-weight: 800; margin: 0 0 10px; text-transform: uppercase; }}
    .nav-link {{
      display: block;
      color: #cbd8e7;
      border: 1px solid transparent;
      border-radius: 8px;
      padding: 9px 10px;
      text-decoration: none;
      font-size: 13px;
      margin-bottom: 6px;
    }}
    .nav-link:hover {{ background: #1e2329; border-color: #343b45; color: var(--amber); }}
    .mobile-nav .nav-link {{ white-space: nowrap; margin: 0; background: #181a20; }}
    .layout {{ display: grid; grid-template-columns: minmax(0, 1.9fr) minmax(340px, .8fr); gap: 8px; }}
    .wide-section {{ grid-column: 1 / -1; }}
    .history-table th:nth-child(1), .history-table td:nth-child(1) {{ width: 118px; }}
    .history-table th:nth-child(2), .history-table td:nth-child(2) {{ min-width: 190px; }}
    .history-table th:nth-child(4), .history-table td:nth-child(4) {{ min-width: 230px; }}
    .history-table th:nth-child(10), .history-table td:nth-child(10) {{ width: 148px; min-width: 148px; }}
    .grid {{ display: grid; grid-template-columns: repeat(7, minmax(120px, 1fr)); gap: 1px; margin: 0 0 8px; background: var(--line); border: 1px solid var(--line); }}
    .card {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 4px;
      padding: 12px;
      box-shadow: none;
    }}
    .grid .card {{ border: 0; border-radius: 0; min-height: 66px; }}
    .metric {{ font-size: 22px; font-weight: 800; line-height: 1; font-variant-numeric: tabular-nums; }}
    .metric.green, .win, .pos {{ color: var(--green); }}
    .metric.red, .loss, .neg {{ color: var(--red); }}
    .metric.amber, .void, .open, .flat {{ color: var(--amber); }}
    .muted {{ color: var(--muted); font-size: 12px; }}
    .card .muted {{ line-height: 1.35; }}
    .chip {{ border: 1px solid var(--line); border-radius: 4px; display: inline-flex; padding: 7px 10px; color: #111; background: var(--amber); font-size: 12px; font-weight: 800; gap: 6px; }}
    .status-dot {{ width: 8px; height: 8px; border-radius: 999px; background: var(--green); margin-top: 4px; }}
    .status-dot.amber {{ background: var(--amber); }}
    .status-dot.red {{ background: var(--red); }}
    .active-title {{ font-size: 20px; font-weight: 800; margin-bottom: 8px; }}
    .active-line {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 14px; }}
    .mini {{ background: #11151c; border: 1px solid var(--line); border-radius: 4px; padding: 9px; }}
    .table-wrap {{ overflow-x: auto; border: 1px solid var(--line); border-radius: 4px; background: var(--panel); }}
    table {{ width: 100%; border-collapse: collapse; background: var(--panel); overflow: hidden; }}
    th, td {{ padding: 7px 8px; border-bottom: 1px solid #242a33; text-align: left; font-size: 12px; vertical-align: top; font-variant-numeric: tabular-nums; }}
    th {{ background: #1e2329; color: #aeb4bc; font-weight: 700; text-transform: none; font-size: 11px; }}
    tr:hover td {{ background: #202630; }}
    .links a {{ display: inline-block; margin: 4px 10px 4px 0; color: var(--cyan); text-decoration: none; }}
    .section {{ margin-top: 16px; }}
    .subtle {{ color: #b5c4d6; line-height: 1.45; }}
    textarea {{
      width: 100%;
      min-height: 160px;
      resize: vertical;
      border: 1px solid var(--line);
      border-radius: 4px;
      background: #0b0e11;
      color: var(--text);
      padding: 12px;
      font: inherit;
      font-size: 13px;
      line-height: 1.4;
    }}
    button {{
      border: 0;
      border-radius: 8px;
      background: var(--amber);
      color: #141414;
      cursor: pointer;
      font-weight: 800;
      margin-top: 10px;
      padding: 10px 14px;
    }}
    button:disabled {{ cursor: wait; opacity: .65; }}
    button.ghost {{
      align-items: center;
      background: #1e2329;
      border: 1px solid #343b45;
      border-radius: 4px;
      color: #eaecef;
      display: inline-flex;
      font-size: 11px;
      gap: 5px;
      height: 28px;
      justify-content: center;
      margin-top: 0;
      min-width: 64px;
      padding: 0 8px;
    }}
    button.ghost:hover {{ border-color: var(--amber); color: var(--amber); }}
    button.danger {{
      background: rgba(255, 90, 104, .12);
      border-color: rgba(255, 90, 104, .36);
      color: var(--red);
    }}
    button.danger:hover {{ border-color: var(--red); color: #fff; }}
    button.success {{
      background: rgba(14, 203, 129, .12);
      border-color: rgba(14, 203, 129, .36);
      color: var(--green);
    }}
    button.success:hover {{ border-color: var(--green); color: #fff; }}
    .action-buttons {{
      align-items: center;
      display: flex;
      gap: 6px;
      justify-content: flex-end;
      white-space: nowrap;
    }}
    .notice {{ min-height: 20px; margin-top: 8px; }}
    .section-head {{
      align-items: center;
      display: flex;
      gap: 12px;
      justify-content: space-between;
      margin-bottom: 12px;
    }}
    .section-head h2 {{ margin: 0; }}
    #simulador {{
      min-height: 420px;
      position: relative;
      background:
        linear-gradient(rgba(43,49,57,.45) 1px, transparent 1px),
        linear-gradient(90deg, rgba(43,49,57,.45) 1px, transparent 1px),
        radial-gradient(circle at 50% 45%, rgba(252,213,53,.08), transparent 34%),
        var(--panel);
      background-size: 100% 40px, 80px 100%, auto, auto;
    }}
    #simulador::before {{
      content: "BETSIGNAL";
      position: absolute;
      inset: 120px 0 auto;
      text-align: center;
      color: rgba(132,142,156,.08);
      font-size: clamp(44px, 8vw, 92px);
      font-weight: 900;
      letter-spacing: 4px;
      pointer-events: none;
    }}
    #simulador > * {{ position: relative; }}
    .market-pulse {{
      display: grid;
      gap: 8px;
    }}
    .pulse-row {{
      align-items: center;
      background: #11151c;
      border: 1px solid var(--line);
      border-radius: 4px;
      display: grid;
      gap: 10px;
      grid-template-columns: 34px minmax(0, 1fr) 88px 54px;
      padding: 9px;
    }}
    .pulse-rank {{
      color: var(--amber);
      font-size: 16px;
      font-weight: 900;
      text-align: center;
    }}
    .pulse-main strong {{ display: block; font-size: 13px; }}
    .pulse-main span {{ color: var(--muted); display: block; font-size: 11px; margin-top: 2px; }}
    .pulse-meter {{
      background: #0b0e11;
      border: 1px solid #2b3139;
      border-radius: 999px;
      height: 8px;
      overflow: hidden;
    }}
    .pulse-fill {{
      background: linear-gradient(90deg, var(--red), var(--amber), var(--green));
      height: 100%;
      transition: width .45s ease;
    }}
    .pulse-score {{
      font-size: 12px;
      font-weight: 800;
      text-align: right;
    }}
    .scanner-grid {{
      display: grid;
      gap: 8px;
      grid-template-columns: minmax(0, 1.55fr) minmax(320px, .75fr);
      align-items: start;
    }}
    .scanner-grid > .table-wrap {{
      max-height: calc(100vh - 142px);
      overflow: auto;
    }}
    .stats-panel {{
      background: #181a20;
      border: 1px solid var(--line);
      border-radius: 4px;
      max-height: calc(100vh - 142px);
      min-height: min(420px, calc(100vh - 142px));
      overflow-y: auto;
      padding: 12px;
      position: sticky;
      scrollbar-color: var(--amber) #11151c;
      scrollbar-width: thin;
      top: 82px;
    }}
    .stats-panel::-webkit-scrollbar, .scanner-grid > .table-wrap::-webkit-scrollbar {{
      height: 10px;
      width: 10px;
    }}
    .stats-panel::-webkit-scrollbar-track, .scanner-grid > .table-wrap::-webkit-scrollbar-track {{
      background: #11151c;
    }}
    .stats-panel::-webkit-scrollbar-thumb, .scanner-grid > .table-wrap::-webkit-scrollbar-thumb {{
      background: #fcd535;
      border: 2px solid #11151c;
      border-radius: 999px;
    }}
    .stats-tabs {{
      border-bottom: 1px solid var(--line);
      display: flex;
      gap: 20px;
      margin: -2px -2px 12px;
      overflow-x: auto;
      padding: 0 2px;
    }}
    .stats-tab {{
      background: transparent;
      border: 0;
      color: #c7cbd1;
      cursor: pointer;
      font-size: 12px;
      font-weight: 700;
      padding: 8px 0;
      white-space: nowrap;
    }}
    .stats-tab.active {{ border-bottom: 2px solid var(--amber); color: #fff; }}
    .stats-pane {{ display: none; }}
    .stats-pane.active {{ display: block; }}
    .stats-title {{ font-size: 15px; font-weight: 900; margin-bottom: 4px; }}
    .live-card {{
      background: #1c1c1d;
      border: 1px solid #2e353d;
      display: grid;
      gap: 12px;
      margin-top: 12px;
      padding: 14px 10px 16px;
    }}
    .live-xg {{
      align-items: center;
      display: flex;
      gap: 10px;
      justify-content: center;
      font-weight: 900;
    }}
    .live-xg span {{ color: var(--muted); font-size: 11px; font-weight: 700; }}
    .live-metrics {{ display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }}
    .live-stat {{ text-align: center; }}
    .live-label {{ color: #f5f6f7; font-size: 11px; margin-bottom: 6px; }}
    .live-dial-row {{
      align-items: center;
      display: grid;
      gap: 6px;
      grid-template-columns: minmax(28px, 1fr) 34px minmax(28px, 1fr);
    }}
    .live-num {{ font-size: 15px; font-weight: 900; }}
    .live-icons {{
      display: grid;
      gap: 5px;
      grid-template-columns: repeat(3, 1fr);
      margin-top: 9px;
      color: #f5f6f7;
      font-size: 12px;
      font-weight: 900;
    }}
    .flag, .card-dot {{ height: 8px; margin: 0 auto 4px; width: 8px; }}
    .flag {{ background: var(--red); clip-path: polygon(0 0, 100% 45%, 0 90%); }}
    .card-dot.red-card {{ background: var(--red); }}
    .card-dot.yellow-card {{ background: var(--amber); }}
    .shots-line {{ display: grid; grid-template-columns: 42px 1fr 42px; gap: 8px; align-items: center; }}
    .shots-line strong {{ font-size: 13px; text-align: center; }}
    .shots-track {{ background: #e7e9ed; height: 3px; position: relative; }}
    .shots-track span {{ background: var(--red); display: block; height: 3px; margin-left: var(--left-share); width: var(--right-share); }}
    .stats-grid {{ display: grid; gap: 10px; grid-template-columns: 1fr 1fr; margin-top: 12px; }}
    .stat-dial {{
      align-items: center;
      background: #11151c;
      border: 1px solid var(--line);
      border-radius: 4px;
      display: grid;
      gap: 8px;
      grid-template-columns: 1fr 54px 1fr;
      padding: 10px;
      text-align: center;
    }}
    .dial {{
      align-items: center;
      aspect-ratio: 1;
      background: conic-gradient(var(--red) 0 50%, #343b45 50% 100%);
      border-radius: 50%;
      display: grid;
      font-weight: 900;
      place-items: center;
      position: relative;
    }}
    .dial::after {{
      background: #181a20;
      border-radius: 50%;
      content: "";
      height: 62%;
      position: absolute;
      width: 62%;
    }}
    .dial span {{ position: relative; z-index: 1; }}
    .stat-line {{
      background: #11151c;
      border: 1px solid var(--line);
      border-radius: 4px;
      margin-top: 8px;
      padding: 9px;
    }}
    .stat-bar {{ background: #0b0e11; border-radius: 999px; height: 8px; overflow: hidden; }}
    .stat-bar span {{ background: var(--red); display: block; height: 100%; }}
    .clickable-row {{ cursor: pointer; }}
    .clickable-row:hover td {{ background: #26303d; }}
    #ativo, #importar {{ min-height: 210px; }}
    #ia table td:nth-child(2), #ia table td:nth-child(3), .history-table td:nth-child(5), .history-table td:nth-child(8) {{ text-align: right; }}
    .sparkline {{
      display: grid;
      grid-template-columns: repeat(12, 1fr);
      align-items: end;
      gap: 4px;
      height: 64px;
      margin-top: 12px;
    }}
    .bar {{ background: var(--green); border-radius: 3px 3px 0 0; min-height: 8px; }}
    .bar.neg {{ background: var(--red); }}
    @media (max-width: 980px) {{
      .app-shell {{ grid-template-columns: 1fr; }}
      .sidebar {{ display: none; }}
      .mobile-nav {{ display: flex; }}
      .layout {{ grid-template-columns: 1fr; }}
      .scanner-grid {{ grid-template-columns: 1fr; }}
      .scanner-grid > .table-wrap {{ max-height: none; overflow: visible; }}
      .stats-panel {{
        max-height: 72vh;
        min-height: 360px;
        position: static;
      }}
      .wide-section {{ grid-column: auto; }}
      .history-table th, .history-table td {{ width: auto; min-width: 0; }}
      .grid {{ grid-template-columns: 1fr 1fr; }}
      .live-metrics {{ grid-template-columns: 1fr; }}
      .active-line {{ grid-template-columns: 1fr; }}
      .table-wrap {{ border: 0; background: transparent; overflow: visible; }}
      table.responsive {{ display: block; background: transparent; border: 0; }}
      table.responsive thead {{ display: none; }}
      table.responsive tbody {{ display: grid; gap: 10px; }}
      table.responsive tr {{
        display: grid;
        gap: 7px;
        background: linear-gradient(180deg, rgba(17, 29, 43, .96), rgba(10, 18, 28, .96));
        border: 1px solid var(--line);
        border-radius: 8px;
        padding: 12px;
      }}
      table.responsive td {{
        border: 0;
        display: grid;
        grid-template-columns: 92px minmax(0, 1fr);
        gap: 8px;
        padding: 0;
        font-size: 13px;
        line-height: 1.35;
      }}
      table.responsive td::before {{
        content: attr(data-label);
        color: var(--muted);
        font-size: 11px;
        font-weight: 800;
        text-transform: uppercase;
      }}
      .action-buttons {{ justify-content: stretch; }}
      .action-buttons button {{ flex: 1; min-width: 0; }}
      main {{ padding: 14px 12px 28px; }}
      .topbar {{ padding: 14px 16px; }}
      h1 {{ font-size: 20px; }}
      .metric {{ font-size: 22px; }}
      th, td {{ padding: 10px 8px; font-size: 12px; }}
    }}
    @media (max-width: 520px) {{
      .grid {{ grid-template-columns: 1fr; }}
      .ticker {{ padding: 8px 12px; }}
      .topbar {{ align-items: flex-start; flex-direction: column; gap: 10px; }}
      .mobile-nav {{ top: 116px; padding-inline: 12px; }}
      table.responsive td {{ grid-template-columns: 78px minmax(0, 1fr); }}
      textarea {{ min-height: 132px; }}
      button {{ width: 100%; }}
    }}
  </style>
</head>
<body>
  <header>
    <div class="topbar">
      <div>
        <h1>{product_name}</h1>
        <div class="muted">{product_tagline}</div>
      </div>
      <div class="chip"><span class="status-dot"></span> Sistema online</div>
    </div>
    <div class="ticker">
      <div>GREENS <span>{stats["wins"]}</span></div>
      <div>REDS <span class="neg">{stats["losses"]}</span></div>
      <div>HIT RATE <span>{stats["hit_rate"]}%</span></div>
      <div>ROI <span class="{_value_class(stats["roi_units"])}">{stats["roi_units"]}%</span></div>
      <div>LUCRO <span class="{_value_class(stats["profit_units"])}">{stats["profit_units"]}u</span></div>
      <div>IA <span>{stats["readiness"]}</span></div>
    </div>
  </header>
  <nav class="mobile-nav">
    <a class="nav-link" href="#scanner">Scanner</a>
    <a class="nav-link" href="#simulador">Simulador</a>
    <a class="nav-link" href="#entradas">Entradas</a>
    <a class="nav-link" href="#importar">Importar</a>
    <a class="nav-link" href="#historico">Historico</a>
    <a class="nav-link" href="#comercial">Comercial</a>
    <a class="nav-link" href="#supabase">Supabase</a>
  </nav>
  <div class="app-shell">
  <aside class="sidebar">
    <p class="nav-title">Operacao</p>
    <a class="nav-link" href="#scanner">Scanner</a>
    <a class="nav-link" href="#simulador">Simulador</a>
    <a class="nav-link" href="#ativo">Jogo ativo</a>
    <a class="nav-link" href="#entradas">Entradas</a>
    <a class="nav-link" href="#importar">Importar Bet365</a>
    <a class="nav-link" href="#historico">Historico</a>
    <a class="nav-link" href="#comercial">Comercial</a>
    <a class="nav-link" href="#ia">Rankings IA</a>
    <a class="nav-link" href="/api/state">API JSON</a>
  </aside>
  <main>
    <section class="grid">
      <div class="card"><div class="metric">{stats["total"]}</div><div class="muted">Sinais registrados</div></div>
      <div class="card"><div class="metric green">{stats["wins"]}</div><div class="muted">Greens</div></div>
      <div class="card"><div class="metric red">{stats["losses"]}</div><div class="muted">Reds</div></div>
      <div class="card"><div class="metric">{stats["hit_rate"]}%</div><div class="muted">Taxa de acerto</div></div>
      <div class="card"><div class="metric {_value_class(manual_stats["profit_currency"])}">R$ {manual_stats["profit_currency"]}</div><div class="muted">Resultado manual</div></div>
      <div class="card"><div class="metric">{manual_stats["total"]}</div><div class="muted">Apostas importadas</div></div>
      <div class="card"><div class="metric {_value_class(stats["profit_units"])}">{stats["profit_units"]}u</div><div class="muted">Lucro em unidades</div></div>
      <div class="card"><div class="metric {_value_class(stats["roi_units"])}">{stats["roi_units"]}%</div><div class="muted">ROI por unidade</div></div>
      <div class="card"><div class="metric amber">{stats["brier_score"]}</div><div class="muted">Brier score</div></div>
      <div class="card"><div class="metric">{stats["readiness"]}</div><div class="muted">Maturidade IA</div></div>
      <div class="card"><div class="metric">{_esc(fast_learning.get("mode", "neutro"))}</div><div class="muted">Modo rapido</div></div>
      <div class="card"><div class="metric">{_esc(fast_learning.get("momentum_score", 50))}/100</div><div class="muted">Momentum IA</div></div>
      <div class="card"><div class="metric {_value_class(backtest.get("profit_units"))}">{backtest.get("profit_units", 0)}u</div><div class="muted">Backtest lucro</div></div>
      <div class="card"><div class="metric red">{backtest.get("max_drawdown_units", 0)}u</div><div class="muted">Drawdown max</div></div>
      <div class="card"><div class="metric">{_best_name(learning.get("by_market"))}</div><div class="muted">Melhor mercado</div></div>
      <div class="card"><div class="metric">{_best_name(learning.get("by_team"))}</div><div class="muted">Melhor time</div></div>
    </section>
    <section class="card section" id="scanner">
      <h2>Scanner Mundial</h2>
      <div class="active-line">
        <div class="mini"><div class="muted">Modo</div><strong>{scanner["mode"]}</strong></div>
        <div class="mini"><div class="muted">Ultimo ciclo</div><strong>{scanner["last_scan"]}</strong></div>
        <div class="mini"><div class="muted">Candidatos</div><strong>{scanner["candidates"]}</strong></div>
        <div class="mini"><div class="muted">Jogos do dia</div><strong>{scanner["today_games"]}</strong></div>
        <div class="mini"><div class="muted">Cobertura</div><strong>Brasil primeiro + ligas globais ESPN</strong></div>
        <div class="mini"><div class="muted">Seguranca</div><strong>HTTPS, Basic Auth, headers anti-frame</strong></div>
        <div class="mini"><div class="muted">Status</div><strong>{scanner["status"]}</strong></div>
      </div>
    </section>
    <section class="card section" id="supabase">
      <h2>Supabase e Fontes</h2>
      <div class="active-line">
        <div class="mini"><div class="muted">Supabase</div><strong>{supabase_info["status"]}</strong></div>
        <div class="mini"><div class="muted">Jogos</div><strong>{supabase_info["games"]}</strong></div>
        <div class="mini"><div class="muted">Sinais</div><strong>{supabase_info["signals"]}</strong></div>
        <div class="mini"><div class="muted">Memoria IA</div><strong>{supabase_info["memory"]}</strong></div>
        <div class="mini"><div class="muted">Fontes IA</div><strong>{len(FOOTBALL_DATA_SOURCES)} catalogadas</strong></div>
        <div class="mini"><div class="muted">Modo</div><strong>Simulacao, sem auto-aposta</strong></div>
      </div>
    </section>
    <section class="card section" id="simulador">
      <div class="section-head">
        <h2>Simulador Em Tempo Real</h2>
        <span id="simulator-status" class="muted">Atualizado: {simulator_updated_at} | auto 60 min</span>
      </div>
      <div id="simulator-best">{best_simulation}</div>
      <section class="card section" id="termometro">
        <div class="section-head">
          <h2>Termometro Do Jogo</h2>
          <span class="muted">ranking dinamico de entradas</span>
        </div>
        <div id="thermometer-rows" class="market-pulse">{thermometer_rows}</div>
      </section>
      <div class="scanner-grid">
        <div class="table-wrap"><table class="responsive">
          <thead><tr><th>Jogo</th><th>Mercado</th><th>Selecao</th><th>Linha</th><th>Odd</th><th>Acao</th><th>Score</th><th>Leitura</th></tr></thead>
          <tbody id="simulator-rows">{simulation_rows or '<tr><td colspan="8">Aguardando sinais do scanner.</td></tr>'}</tbody>
        </table></div>
        <aside class="stats-panel" id="match-stats">{match_stats}</aside>
      </div>
    </section>
    <div class="layout">
      <div>
        <section class="card" id="ativo">
          <h2>Jogo Ativo</h2>
          {active}
        </section>
        <section class="section" id="entradas">
          <h2>Entradas Em Andamento</h2>
          <div class="table-wrap"><table class="responsive">
            <thead><tr><th>Entrada</th><th>Jogo</th><th>Mercado</th><th>Valor</th><th>Odd</th><th>Acao</th></tr></thead>
            <tbody>{active_entry_rows or '<tr><td colspan="6">Nenhuma entrada em andamento.</td></tr>'}</tbody>
          </table></div>
        </section>
        <section class="card section" id="importar">
          <h2>Importar Bet365</h2>
          <p class="muted">Cole texto bruto ou HTML copiado. O app limpa scripts, metadados e preloader; so importa linhas com aposta, valor, green/red/perdida.</p>
          <textarea id="bet365-import" placeholder="Cole aqui o historico copiado da Bet365, mesmo que venha com HTML"></textarea>
          <button id="import-button" type="button" onclick="importHistory()">Importar historico</button>
          <div id="import-result" class="notice muted"></div>
        </section>
        <section class="card section">
          <h2>Curva da Banca</h2>
          {_equity_curve(backtest)}
        </section>
      </div>
      <aside>
        <section class="card">
          <h2>Leitura Para Proximos Jogos</h2>
          <p class="subtle">{advice}</p>
          <p class="muted">Amostra usada pela IA: {learning.get("sample_size", 0)} resultados fechados.</p>
        </section>
        <section class="card section" id="ia">
          <h2>Rankings IA</h2>
          {rankings}
        </section>
        <section class="card section">
          <h2>Aprendizado Rapido</h2>
          {fast_panel}
        </section>
        <section class="card section">
          <h2>Fontes Para IA</h2>
          {source_panel}
        </section>
        <section class="card section" id="comercial">
          <h2>Oferta Comercial</h2>
          {commercial_panel}
        </section>
        <section class="card section">
          <h2>Acessos</h2>
          <div class="links">{domains}</div>
          <p class="muted">Se o dominio nao abrir, confirme DNS A para 2.24.217.214.</p>
        </section>
        <section class="card section">
          <h2>Suporte</h2>
          <p class="subtle">{support}</p>
          <p class="muted">No Telegram use /suporte para resumo tecnico.</p>
        </section>
      </aside>
    </div>
    <section class="section wide-section" id="historico">
      <h2>Historico de Operacoes</h2>
      <div class="table-wrap"><table class="responsive history-table">
        <thead><tr><th>Data</th><th>Jogo</th><th>Liga</th><th>Entrada</th><th>Valor real</th><th>Conf.</th><th>Edge</th><th>Stake</th><th>Resultado</th><th>Acao</th></tr></thead>
        <tbody>{rows or '<tr><td colspan="10">Nenhum green/red registrado ainda.</td></tr>'}</tbody>
      </table></div>
    </section>
  </main>
  </div>
</body>
<script>
  async function importHistory() {{
    const box = document.getElementById('bet365-import');
    const button = document.getElementById('import-button');
    const result = document.getElementById('import-result');
    const text = box.value.trim();
    if (!text) {{
      result.textContent = 'Cole o historico antes de importar.';
      return;
    }}
    button.disabled = true;
    result.textContent = 'Importando...';
    try {{
      const response = await fetch('/api/import-history', {{
        method: 'POST',
        headers: {{'Content-Type': 'application/json'}},
        body: JSON.stringify({{text}})
      }});
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Falha ao importar');
      result.textContent = `Importado: ${{data.imported}} | Greens: ${{data.wins}} | Reds: ${{data.losses}}`;
      setTimeout(() => window.location.reload(), 900);
    }} catch (error) {{
      result.textContent = error.message;
    }} finally {{
      button.disabled = false;
    }}
  }}

  function parseMoneyInput(value) {{
    if (value === null) return null;
    let clean = value.trim().replace('R$', '').replace(/\\s/g, '');
    if (clean.includes(',')) {{
      clean = clean.replace(/\\./g, '').replace(',', '.');
    }}
    if (!clean) return null;
    const number = Number(clean);
    return Number.isFinite(number) ? number : null;
  }}

  async function editHistoryValue(signalId, currentValue, currentOdds, currentProfit) {{
    const value = parseMoneyInput(prompt('Valor real apostado em R$:', currentValue || ''));
    if (value === null) return;
    const odds = parseMoneyInput(prompt('Odd real usada:', currentOdds || ''));
    const profit = parseMoneyInput(prompt('Lucro real em R$ se foi Green. Deixe vazio para calcular pela odd:', currentProfit || ''));
    try {{
      const response = await fetch('/api/history-value', {{
        method: 'POST',
        headers: {{'Content-Type': 'application/json'}},
        body: JSON.stringify({{
          signal_id: signalId,
          entry_value: value,
          entry_odds: odds,
          profit_value: profit
        }})
      }});
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Falha ao salvar valor');
      window.location.reload();
    }} catch (error) {{
      alert(error.message);
    }}
  }}

  async function deleteHistoryRecord(signalId) {{
    if (!confirm('Excluir este registro do historico?')) return;
    try {{
      const response = await fetch('/api/history-delete', {{
        method: 'POST',
        headers: {{'Content-Type': 'application/json'}},
        body: JSON.stringify({{signal_id: signalId}})
      }});
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Falha ao excluir registro');
      window.location.reload();
    }} catch (error) {{
      alert(error.message);
    }}
  }}

  async function closeEntry(signalId, outcome) {{
    const label = outcome === 'win' ? 'Green' : 'Red';
    if (!confirm(`Marcar esta entrada como ${{label}}?`)) return;
    try {{
      const response = await fetch('/api/history-outcome', {{
        method: 'POST',
        headers: {{'Content-Type': 'application/json'}},
        body: JSON.stringify({{signal_id: signalId, outcome}})
      }});
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Falha ao fechar entrada');
      window.location.reload();
    }} catch (error) {{
      alert(error.message);
    }}
  }}

  async function refreshSimulator() {{
    const status = document.getElementById('simulator-status');
    const best = document.getElementById('simulator-best');
    const rows = document.getElementById('simulator-rows');
    if (!status || !best || !rows) return;
    try {{
      status.textContent = 'Atualizando simulador...';
      const response = await fetch('/api/simulator', {{cache: 'no-store'}});
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Falha ao atualizar simulador');
      best.innerHTML = data.best_html;
      rows.innerHTML = data.rows_html || '<tr><td colspan="8">Aguardando sinais do scanner.</td></tr>';
      const thermometer = document.getElementById('thermometer-rows');
      if (thermometer) thermometer.innerHTML = data.thermometer_html;
      const stats = document.getElementById('match-stats');
      if (stats && window.selectedGameId) {{
        await updateSelectedMatchStats(window.selectedGameId, false);
      }} else if (stats && data.match_stats_html) {{
        stats.innerHTML = data.match_stats_html;
        window.selectedGameId = data.default_game_id || null;
      }}
      status.textContent = `Atualizado: ${{data.updated_at}} | auto 60 min`;
    }} catch (error) {{
      status.textContent = `Falha ao atualizar: ${{error.message}}`;
    }}
  }}

  window.setInterval(refreshSimulator, 60 * 1000);
  window.setInterval(() => {{
    const active = document.activeElement;
    const typing = active && ['TEXTAREA', 'INPUT'].includes(active.tagName);
    if (!typing) window.location.reload();
  }}, 5 * 60 * 1000);

  async function selectScannedGame(gameId) {{
    window.selectedGameId = gameId;
    await updateSelectedMatchStats(gameId, true);
  }}

  async function updateSelectedMatchStats(gameId, showLoading) {{
    const panel = document.getElementById('match-stats');
    if (!panel) return;
    if (showLoading) {{
      panel.scrollTo({{top: 0, behavior: 'smooth'}});
      panel.innerHTML = '<p class="muted">Carregando estatisticas do jogo...</p>';
    }}
    try {{
      const response = await fetch(`/api/match-stats?game_id=${{encodeURIComponent(gameId)}}`, {{cache: 'no-store'}});
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Falha ao carregar jogo');
      panel.innerHTML = data.html;
      if (showLoading) panel.scrollTo({{top: 0, behavior: 'smooth'}});
    }} catch (error) {{
      panel.innerHTML = `<p class="muted">${{error.message}}</p>`;
      if (showLoading) panel.scrollTo({{top: 0, behavior: 'smooth'}});
    }}
  }}
  window.selectedGameId = null;

  function switchStatsTab(button, paneId) {{
    const panel = button.closest('.stats-panel');
    if (!panel) return;
    panel.querySelectorAll('.stats-tab').forEach(tab => tab.classList.remove('active'));
    panel.querySelectorAll('.stats-pane').forEach(pane => pane.classList.remove('active'));
    button.classList.add('active');
    const pane = panel.querySelector(`#${{paneId}}`);
    if (pane) pane.classList.add('active');
  }}
</script>
</html>"""


@app.get("/api/state")
def api_state(_: None = Depends(_auth)) -> JSONResponse:
    settings = load_settings()
    state = StateStore(os.getenv("STATE_FILE", "data/state.json")).load()
    history = state.history or []
    visible_history = _green_red(history)
    return JSONResponse(
        {
            "active_signal": state.active_signal,
            "active_entries": _active_entries(history, state.active_signal),
            "history": visible_history,
            "stats": _stats(visible_history),
            "learning": summarize_history(visible_history),
            "scanner": _scanner_status(state),
            "paper_opportunities": paper_opportunities(_simulation_signals(state)),
            "best_paper_entry": best_paper_entry(_simulation_signals(state)),
            "domains": [
                item.strip()
                for item in settings.dashboard_domains.split(",")
                if item.strip()
            ],
        }
    )


@app.get("/api/simulator")
def api_simulator(_: None = Depends(_auth)) -> JSONResponse:
    state = StateStore(os.getenv("STATE_FILE", "data/state.json")).load()
    simulation_signals = _simulation_signals(state)
    opportunities = paper_opportunities(simulation_signals)
    default_signal = simulation_signals[0] if simulation_signals else None
    simulation_rows = "\n".join(
        _simulation_row(item) for item in opportunities
    )
    return JSONResponse(
        {
            "best_html": _best_simulation(best_paper_entry(simulation_signals)),
            "rows_html": simulation_rows,
            "thermometer_html": _thermometer_rows(opportunities),
            "match_stats_html": _match_stats_panel(default_signal, _green_red(state.history or [])),
            "default_game_id": (default_signal.get("game") or {}).get("game_id") if default_signal else None,
            "updated_at": _short_datetime(state.last_scan_at),
        }
    )


@app.get("/api/match-stats")
def api_match_stats(game_id: str, _: None = Depends(_auth)) -> JSONResponse:
    state = StateStore(os.getenv("STATE_FILE", "data/state.json")).load()
    history = _green_red(state.history or [])
    signals = _simulation_signals(state)
    selected = next(
        (
            signal
            for signal in signals
            if str((signal.get("game") or {}).get("game_id")) == str(game_id)
        ),
        None,
    )
    if not selected:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Jogo nao encontrado nos escaneados.",
        )
    return JSONResponse({"html": _match_stats_panel(selected, history)})


@app.post("/api/import-history")
async def import_history(payload: ImportPayload, _: None = Depends(_auth)) -> JSONResponse:
    records = parse_manual_bets(payload.text)
    if not records:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nenhuma aposta encontrada no texto enviado.",
        )
    settings = load_settings()
    store = StateStore(os.getenv("STATE_FILE", "data/state.json"))
    state = store.add_history_records(records)
    sink = SupabaseSink.from_settings(settings)
    await sink.sync_signals(records)
    await sink.sync_ai_memory(state.history or [])
    return JSONResponse(
        {
            "imported": len(records),
            "wins": sum(1 for item in records if item.get("outcome") == "win"),
            "losses": sum(1 for item in records if item.get("outcome") == "loss"),
            "voids": sum(1 for item in records if item.get("outcome") == "void"),
            "opens": sum(1 for item in records if item.get("outcome") == "open"),
            "profit_currency": _manual_stats(records)["profit_currency"],
        }
    )


@app.post("/api/history-value")
async def update_history_value(
    payload: HistoryValuePayload,
    _: None = Depends(_auth),
) -> JSONResponse:
    if payload.entry_value is None and payload.entry_odds is None and payload.profit_value is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Informe pelo menos valor, odd ou lucro.",
        )
    settings = load_settings()
    store = StateStore(os.getenv("STATE_FILE", "data/state.json"))
    before = store.load()
    if not any(str(item.get("signal_id")) == str(payload.signal_id) for item in before.history or []):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Registro nao encontrado no historico.",
        )
    state = store.update_history_value(
        payload.signal_id,
        payload.entry_value,
        payload.entry_odds,
        payload.profit_value,
    )
    updated = next(
        item for item in state.history or [] if str(item.get("signal_id")) == str(payload.signal_id)
    )
    sink = SupabaseSink.from_settings(settings)
    await sink.sync_signal(updated)
    await sink.sync_ai_memory(state.history or [])
    return JSONResponse({"ok": True, "record": updated})


@app.post("/api/history-delete")
async def delete_history_record(
    payload: HistoryDeletePayload,
    _: None = Depends(_auth),
) -> JSONResponse:
    settings = load_settings()
    store = StateStore(os.getenv("STATE_FILE", "data/state.json"))
    state, deleted = store.delete_history_record(payload.signal_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Registro nao encontrado no historico.",
        )
    sink = SupabaseSink.from_settings(settings)
    await sink.sync_ai_memory(state.history or [])
    return JSONResponse({"ok": True})


@app.post("/api/history-outcome")
async def close_history_entry(
    payload: HistoryOutcomePayload,
    _: None = Depends(_auth),
) -> JSONResponse:
    outcome = payload.outcome.lower().strip()
    if outcome not in {"win", "loss"}:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Resultado invalido. Use win ou loss.",
        )
    settings = load_settings()
    store = StateStore(os.getenv("STATE_FILE", "data/state.json"))
    state, updated = store.mark_history_outcome(payload.signal_id, outcome)
    if not updated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Entrada nao encontrada.",
        )
    sink = SupabaseSink.from_settings(settings)
    await sink.sync_signal(updated)
    await sink.sync_ai_memory(state.history or [])
    return JSONResponse({"ok": True, "record": updated})


def _stats(history: list[dict[str, Any]]) -> dict[str, Any]:
    learning = summarize_history(history)
    settled = _green_red(history)
    wins = sum(1 for item in settled if item.get("outcome") == "win")
    losses = sum(1 for item in settled if item.get("outcome") == "loss")
    hit_rate = round((wins / len(settled)) * 100, 1) if settled else 0
    sample = learning.get("sample_size", 0)
    readiness = "baixa" if sample < 30 else "media" if sample < 100 else "alta"
    return {
        "total": len(settled),
        "wins": wins,
        "losses": losses,
        "hit_rate": hit_rate,
        "profit_units": learning.get("profit_units", 0),
        "roi_units": learning.get("roi_units", 0),
        "brier_score": learning.get("brier_score") or "-",
        "readiness": readiness,
    }


def _manual_stats(history: list[dict[str, Any]]) -> dict[str, Any]:
    manual = [item for item in _green_red(history) if item.get("source") == "manual_import"]
    wins = [item for item in manual if item.get("outcome") == "win"]
    losses = [item for item in manual if item.get("outcome") == "loss"]
    stake_loss = sum(float(item.get("entry_value") or 0) for item in losses)
    profit = -stake_loss + sum(float(item.get("profit_value") or 0) for item in wins)
    closed = len(wins) + len(losses)
    return {
        "total": len(wins) + len(losses),
        "wins": len(wins),
        "losses": len(losses),
        "hit_rate": round((len(wins) / closed) * 100, 1) if closed else 0,
        "profit_currency": round(profit, 2),
    }


def _green_red(history: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [item for item in history if item.get("outcome") in {"win", "loss"}]


def _simulation_signals(state) -> list[dict[str, Any]]:
    signals = []
    if state.active_signal:
        signals.append(state.active_signal)
    signals.extend(state.candidate_signals or [])
    seen = set()
    deduped = []
    for signal in signals:
        if not isinstance(signal, dict):
            continue
        game_id = (signal.get("game") or {}).get("game_id")
        if not game_id or game_id in seen:
            continue
        seen.add(game_id)
        deduped.append(signal)
    return deduped


def _best_simulation(item: dict[str, Any] | None) -> str:
    if not item:
        return "<p class='muted'>Nenhuma oportunidade simulada no momento.</p>"
    return (
        "<div class='active-line'>"
        f"<div class='mini'><div class='muted'>Melhor jogo</div><strong>{_esc(item.get('match'))}</strong></div>"
        f"<div class='mini'><div class='muted'>Mercado</div><strong>{_esc(item.get('market'))}</strong></div>"
        f"<div class='mini'><div class='muted'>Entrada</div><strong>{_esc(item.get('selection'))} {_esc(item.get('line'))}</strong></div>"
        f"<div class='mini'><div class='muted'>Odd</div><strong>{_esc(item.get('odds') or 'sem odd')}</strong></div>"
        f"<div class='mini'><div class='muted'>Score</div><strong>{_esc(item.get('score'))}/100</strong></div>"
        f"<div class='mini'><div class='muted'>Acao</div><strong>{_esc(item.get('action'))}</strong></div>"
        "</div>"
    )


def _simulation_row(item: dict[str, Any]) -> str:
    game_id = _js_string(item.get("game_id") or "")
    return (
        f"<tr class='clickable-row' onclick=\"selectScannedGame('{game_id}')\">"
        f"<td data-label='Jogo'>{_esc(item.get('match'))}<br><span class='muted'>{_esc(item.get('league'))} | { _esc(item.get('minute'))}' | { _esc(item.get('scoreline'))}</span></td>"
        f"<td data-label='Mercado'>{_esc(item.get('market'))}</td>"
        f"<td data-label='Selecao'>{_esc(item.get('selection'))}</td>"
        f"<td data-label='Linha'>{_esc(item.get('line'))}</td>"
        f"<td data-label='Odd'>{_esc(item.get('odds') or '-')}</td>"
        f"<td data-label='Acao' class='{_action_class(item.get('action'))}'>{_esc(item.get('action'))}</td>"
        f"<td data-label='Score'>{_esc(item.get('score'))}/100<br><span class='muted'>risco { _esc(item.get('risk'))}/100</span></td>"
        f"<td data-label='Leitura'>{_esc(item.get('reason'))}</td>"
        "</tr>"
    )


def _thermometer_rows(items: list[dict[str, Any]]) -> str:
    if not items:
        return "<p class='muted'>Aguardando sinais para montar o termometro.</p>"
    ranked = sorted(
        items,
        key=lambda item: (
            _action_weight(item.get("action")),
            int(item.get("score") or 0) - int(item.get("risk") or 0),
            int(item.get("score") or 0),
        ),
        reverse=True,
    )
    rows = []
    for idx, item in enumerate(ranked[:6], start=1):
        score = max(0, min(100, int(item.get("score") or 0)))
        risk = max(0, min(100, int(item.get("risk") or 0)))
        heat = max(4, min(100, score if score else 100 - risk))
        rows.append(
            f"<div class='pulse-row clickable-row' onclick=\"selectScannedGame('{_js_string(item.get('game_id') or '')}')\">"
            f"<div class='pulse-rank'>{idx}</div>"
            "<div class='pulse-main'>"
            f"<strong>{_esc(item.get('selection'))} {_esc(item.get('line'))}</strong>"
            f"<span>{_esc(item.get('match'))} | {_esc(item.get('market'))} | odd {_esc(item.get('odds') or '-')}</span>"
            "</div>"
            "<div class='pulse-meter'>"
            f"<div class='pulse-fill' style='width:{heat}%'></div>"
            "</div>"
            f"<div class='pulse-score'>{_esc(item.get('action'))}<br><span class='muted'>{score}/100</span></div>"
            "</div>"
        )
    return "".join(rows)


def _match_stats_panel(signal: dict[str, Any] | None, history: list[dict[str, Any]]) -> str:
    if not signal:
        return (
            "<div class='stats-tabs'>"
            "<button class='stats-tab active' type='button'>Estat.</button>"
            "<button class='stats-tab' type='button'>Historico</button>"
            "<button class='stats-tab' type='button'>Jogadores</button>"
            "</div>"
            "<p class='muted'>Clique em um jogo escaneado para abrir estatisticas, historico dos times e termometro.</p>"
        )
    game = signal.get("game") or {}
    home = str(game.get("home") or "Mandante")
    away = str(game.get("away") or "Visitante")
    metrics = _dynamic_match_metrics(signal)
    home_goals = int(game.get("home_goals") or 0)
    away_goals = int(game.get("away_goals") or 0)
    home_hist = _team_history(home, history)
    away_hist = _team_history(away, history)
    panel_id = _safe_dom_id(game.get("game_id") or f"{home}-{away}")
    stats_id = f"stats-{panel_id}"
    history_id = f"history-{panel_id}"
    players_id = f"players-{panel_id}"
    lineup_id = f"lineup-{panel_id}"
    return (
        "<div class='stats-tabs'>"
        f"<button class='stats-tab active' type='button' onclick=\"switchStatsTab(this, '{stats_id}')\">Estat.</button>"
        f"<button class='stats-tab' type='button' onclick=\"switchStatsTab(this, '{history_id}')\">Historico</button>"
        f"<button class='stats-tab' type='button' onclick=\"switchStatsTab(this, '{players_id}')\">Jogadores</button>"
        f"<button class='stats-tab' type='button' onclick=\"switchStatsTab(this, '{lineup_id}')\">Escalacao</button>"
        "</div>"
        f"<div class='stats-title'>{_esc(home)} x {_esc(away)}</div>"
        f"<div class='muted'>{_esc(game.get('league') or game.get('division') or '-')} | { _esc(game.get('minute', '-'))}' | Placar {home_goals}x{away_goals}</div>"
        f"<div id='{stats_id}' class='stats-pane active'>"
        f"{_live_match_card(metrics)}"
        f"{_stat_line('Termometro jogadores ' + home, f'{metrics['home_player_heat']}/100', metrics['home_player_heat'])}"
        f"{_stat_line('Termometro jogadores ' + away, f'{metrics['away_player_heat']}/100', metrics['away_player_heat'])}"
        "</div>"
        f"<div id='{history_id}' class='stats-pane'>{_history_tab(home, away, home_hist, away_hist, history)}</div>"
        f"<div id='{players_id}' class='stats-pane'>{_players_tab(home, away, metrics)}</div>"
        f"<div id='{lineup_id}' class='stats-pane'>{_lineup_tab(home, away, signal, metrics)}</div>"
    )


def _history_tab(
    home: str,
    away: str,
    home_hist: dict[str, int],
    away_hist: dict[str, int],
    history: list[dict[str, Any]],
) -> str:
    recent = _recent_team_history(home, away, history)
    recent_rows = []
    for item in recent[:6]:
        game = item.get("game") or {}
        recent_rows.append(
            "<tr>"
            f"<td>{_esc((item.get('created_at') or '')[:10])}</td>"
            f"<td>{_esc(game.get('home', '-'))} x {_esc(game.get('away', '-'))}</td>"
            f"<td>{_esc(game.get('home_goals', 0))}x{_esc(game.get('away_goals', 0))}</td>"
            f"<td class='{_esc(item.get('outcome', 'open'))}'>{_label(item.get('outcome', 'open'))}</td>"
            "</tr>"
        )
    table = (
        "<table><thead><tr><th>Data</th><th>Jogo</th><th>Placar</th><th>Bet</th></tr></thead>"
        f"<tbody>{''.join(recent_rows) or '<tr><td colspan=\"4\">Sem historico local para estes times.</td></tr>'}</tbody></table>"
    )
    return (
        "<div class='stats-grid'>"
        f"{_team_history_box(home, home_hist)}"
        f"{_team_history_box(away, away_hist)}"
        "</div>"
        f"{table}"
    )


def _players_tab(home: str, away: str, metrics: dict[str, Any]) -> str:
    home_rows = _player_heat_rows(home, metrics, "home")
    away_rows = _player_heat_rows(away, metrics, "away")
    return (
        "<p class='muted'>Termometro estimado por pressao, xG, ataques perigosos, chutes e placar. Quando a fonte entregar jogador nominal, este painel pode receber nomes reais.</p>"
        "<div class='stats-grid'>"
        f"<div>{_player_table(home, home_rows)}</div>"
        f"<div>{_player_table(away, away_rows)}</div>"
        "</div>"
    )


def _lineup_tab(home: str, away: str, signal: dict[str, Any], metrics: dict[str, Any]) -> str:
    game = signal.get("game") or {}
    target = signal.get("team") or "-"
    home_shape = "4-2-3-1" if metrics["home_danger"] >= metrics["away_danger"] else "4-4-2"
    away_shape = "4-2-3-1" if metrics["away_danger"] > metrics["home_danger"] else "4-4-2"
    return (
        "<p class='muted'>Escalacao estimada. A fonte atual nao entregou nomes oficiais de titulares, entao o agente mostra estrutura, lado forte e foco da entrada.</p>"
        "<div class='stats-grid'>"
        f"{_formation_box(home, home_shape, metrics['home_player_heat'])}"
        f"{_formation_box(away, away_shape, metrics['away_player_heat'])}"
        "</div>"
        "<div class='stat-line'>"
        "<div class='muted'>Foco da IA</div>"
        f"<strong>{_esc(target)}</strong>"
        f"<div>Mercado: {_esc(signal.get('entry_market') or signal.get('market') or '-')}</div>"
        f"<div class='muted'>Liga: {_esc(game.get('league') or game.get('division') or '-')}</div>"
        "</div>"
    )


def _live_match_card(metrics: dict[str, Any]) -> str:
    left_share = _share(metrics["home_shots_total"], metrics["away_shots_total"])
    right_share = 100 - left_share
    return (
        "<div class='live-card'>"
        "<div class='live-xg'>"
        f"<strong>{_esc(metrics['home_xg'])}</strong><span>xG</span><strong>{_esc(metrics['away_xg'])}</strong>"
        "</div>"
        "<div class='live-metrics'>"
        f"{_live_metric('Ataques', metrics['home_attacks'], metrics['away_attacks'], 'A')}"
        f"{_live_metric('Ataques Perigosos', metrics['home_danger'], metrics['away_danger'], '»')}"
        f"{_live_metric('% de Posse', metrics['home_possession'], metrics['away_possession'], '%')}"
        "</div>"
        "<div class='live-metrics'>"
        f"{_discipline_box(metrics['home_corners'], metrics['home_red_cards'], metrics['home_yellow_cards'])}"
        "<div>"
        "<div class='live-label'>Finalizacoes / Chutes ao Gol</div>"
        "<div class='shots-line'>"
        f"<strong>{_esc(metrics['home_shots_total'])}/{_esc(metrics['home_shots_on'])}</strong>"
        f"<div class='shots-track' style='--left-share:{left_share}%;--right-share:{right_share}%'><span></span></div>"
        f"<strong>{_esc(metrics['away_shots_total'])}/{_esc(metrics['away_shots_on'])}</strong>"
        "</div>"
        "</div>"
        f"{_discipline_box(metrics['away_yellow_cards'], metrics['away_red_cards'], metrics['away_corners'], reverse=True)}"
        "</div>"
        f"<p class='muted'>Atualiza junto com o scanner. Quando a fonte nao entrega algum dado, o painel estima pela pressao, minuto, chutes, placar e odds.</p>"
        "</div>"
    )


def _live_metric(label: str, left: int, right: int, icon: str) -> str:
    total = max(1, left + right)
    pct = int((left / total) * 100)
    return (
        "<div class='live-stat'>"
        f"<div class='live-label'>{_esc(label)}</div>"
        "<div class='live-dial-row'>"
        f"<span class='live-num'>{_esc(left)}</span>"
        f"<div class='dial' style='background:conic-gradient(var(--red) 0 {pct}%, #454c56 {pct}% 100%)'><span>{_esc(icon)}</span></div>"
        f"<span class='live-num'>{_esc(right)}</span>"
        "</div>"
        "</div>"
    )


def _discipline_box(first: int, second: int, third: int, *, reverse: bool = False) -> str:
    if reverse:
        icons = [
            ("card-dot yellow-card", first),
            ("card-dot red-card", second),
            ("flag", third),
        ]
    else:
        icons = [
            ("flag", first),
            ("card-dot red-card", second),
            ("card-dot yellow-card", third),
        ]
    return (
        "<div class='live-icons'>"
        + "".join(f"<div><div class='{klass}'></div>{_esc(value)}</div>" for klass, value in icons)
        + "</div>"
    )


def _dynamic_match_metrics(signal: dict[str, Any]) -> dict[str, Any]:
    game = signal.get("game") or {}
    minute = max(1, _safe_int(game.get("minute")))
    home_goals = _safe_int(game.get("home_goals"))
    away_goals = _safe_int(game.get("away_goals"))
    home_pressure = _safe_int(game.get("home_pressure"))
    away_pressure = _safe_int(game.get("away_pressure"))
    home_shots_on = _safe_int(game.get("home_shots_on"))
    away_shots_on = _safe_int(game.get("away_shots_on"))

    home_pressure = home_pressure or _estimated_pressure(signal, "home")
    away_pressure = away_pressure or _estimated_pressure(signal, "away")
    home_shots_on = home_shots_on or max(0, round((home_pressure / 100) * max(1, minute / 18)))
    away_shots_on = away_shots_on or max(0, round((away_pressure / 100) * max(1, minute / 18)))

    home_shots_total = max(home_shots_on, round(home_shots_on * 2.1 + home_pressure / 18 + home_goals))
    away_shots_total = max(away_shots_on, round(away_shots_on * 2.1 + away_pressure / 18 + away_goals))
    home_possession = _possession_share(home_pressure, away_pressure)
    away_possession = 100 - home_possession
    home_attacks = max(5, round(home_pressure * 1.12 + minute * 0.28 + home_shots_total * 1.8))
    away_attacks = max(5, round(away_pressure * 1.12 + minute * 0.28 + away_shots_total * 1.8))
    home_danger = max(1, round(home_pressure * 0.62 + home_shots_on * 4.5 + home_goals * 5))
    away_danger = max(1, round(away_pressure * 0.62 + away_shots_on * 4.5 + away_goals * 5))
    home_corners = _market_corner_hint(game, "home") or max(0, round(home_danger / 16 + home_shots_total / 7))
    away_corners = _market_corner_hint(game, "away") or max(0, round(away_danger / 16 + away_shots_total / 7))
    pressure_delta = abs(home_pressure - away_pressure)
    home_yellow = max(0, round((minute / 45) + (away_pressure > home_pressure) + pressure_delta / 55))
    away_yellow = max(0, round((minute / 45) + (home_pressure > away_pressure) + pressure_delta / 55))
    home_red = 1 if home_yellow >= 4 and pressure_delta > 35 else 0
    away_red = 1 if away_yellow >= 4 and pressure_delta > 35 else 0

    return {
        "home_xg": _fmt_decimal(home_shots_on * 0.31 + home_pressure * 0.012 + home_goals * 0.2),
        "away_xg": _fmt_decimal(away_shots_on * 0.31 + away_pressure * 0.012 + away_goals * 0.2),
        "home_attacks": home_attacks,
        "away_attacks": away_attacks,
        "home_danger": home_danger,
        "away_danger": away_danger,
        "home_possession": home_possession,
        "away_possession": away_possession,
        "home_shots_total": home_shots_total,
        "away_shots_total": away_shots_total,
        "home_shots_on": home_shots_on,
        "away_shots_on": away_shots_on,
        "home_corners": home_corners,
        "away_corners": away_corners,
        "home_yellow_cards": home_yellow,
        "away_yellow_cards": away_yellow,
        "home_red_cards": home_red,
        "away_red_cards": away_red,
        "home_player_heat": min(100, max(8, home_pressure + home_shots_on * 6 + home_goals * 10)),
        "away_player_heat": min(100, max(8, away_pressure + away_shots_on * 6 + away_goals * 10)),
    }


def _estimated_pressure(signal: dict[str, Any], side: str) -> int:
    game = signal.get("game") or {}
    confidence = _safe_int(signal.get("confidence"))
    score = _safe_int(signal.get("entry_score"))
    minute = _safe_int(game.get("minute"))
    target = str(signal.get("team") or "").lower()
    team = str(game.get(side) or "").lower()
    base = 38 + min(28, confidence // 4) + min(12, score // 8) + min(8, minute // 12)
    if target and target in team:
        base += 12
    return max(12, min(92, base))


def _market_corner_hint(game: dict[str, Any], side: str) -> int:
    corners = ((game.get("markets") or {}).get("corners") or {})
    item = corners.get(side)
    if isinstance(item, dict):
        return _safe_int(item.get("line"))
    return 0


def _share(left: int, right: int) -> int:
    total = max(1, left + right)
    return max(0, min(100, int((left / total) * 100)))


def _fmt_decimal(value: float) -> str:
    return f"{max(0, value):.2f}"


def _stat_dial(label: str, left: int, right: int) -> str:
    total = max(1, left + right)
    pct = int((left / total) * 100)
    return (
        "<div class='stat-dial'>"
        f"<strong>{_esc(left)}</strong>"
        f"<div class='dial' style='background:conic-gradient(var(--green) 0 {pct}%, var(--red) {pct}% 100%)'><span>{_esc(label[:1])}</span></div>"
        f"<strong>{_esc(right)}</strong>"
        f"<span class='muted' style='grid-column:1/-1'>{_esc(label)}</span>"
        "</div>"
    )


def _stat_line(label: str, value: str, pct: int) -> str:
    pct = max(0, min(100, int(pct or 0)))
    return (
        "<div class='stat-line'>"
        f"<div class='muted'>{_esc(label)}</div>"
        f"<strong>{_esc(value)}</strong>"
        f"<div class='stat-bar'><span style='width:{pct}%'></span></div>"
        "</div>"
    )


def _team_history_box(team: str, data: dict[str, int]) -> str:
    total = data["wins"] + data["draws"] + data["losses"]
    return (
        "<div class='stat-line'>"
        f"<strong>{_esc(team)}</strong>"
        f"<div class='muted'>Jogos parecidos no historico local: {total}</div>"
        f"<div>V {data['wins']} | E {data['draws']} | D {data['losses']}</div>"
        f"<div class='muted'>Bets: Green {data['greens']} | Red {data['reds']}</div>"
        "</div>"
    )


def _team_history(team: str, history: list[dict[str, Any]]) -> dict[str, int]:
    data = {"wins": 0, "draws": 0, "losses": 0, "greens": 0, "reds": 0}
    needle = team.lower()
    for item in history:
        game = item.get("game") or {}
        home = str(game.get("home") or "")
        away = str(game.get("away") or "")
        if needle not in home.lower() and needle not in away.lower():
            continue
        if item.get("outcome") == "win":
            data["greens"] += 1
        elif item.get("outcome") == "loss":
            data["reds"] += 1
        hg = _safe_int(game.get("home_goals"))
        ag = _safe_int(game.get("away_goals"))
        if hg == ag:
            data["draws"] += 1
        elif (needle in home.lower() and hg > ag) or (needle in away.lower() and ag > hg):
            data["wins"] += 1
        else:
            data["losses"] += 1
    return data


def _recent_team_history(home_team: str, away_team: str, history: list[dict[str, Any]]) -> list[dict[str, Any]]:
    home_needle = home_team.lower()
    away_needle = away_team.lower()
    rows = []
    for item in history:
        game = item.get("game") or {}
        home = str(game.get("home") or "").lower()
        away = str(game.get("away") or "").lower()
        if (
            home_needle in home
            or home_needle in away
            or away_needle in home
            or away_needle in away
        ):
            rows.append(item)
    return rows


def _player_heat_rows(team: str, metrics: dict[str, Any], side: str) -> list[dict[str, Any]]:
    prefix = "home" if side == "home" else "away"
    heat = int(metrics[f"{prefix}_player_heat"])
    danger = int(metrics[f"{prefix}_danger"])
    shots = int(metrics[f"{prefix}_shots_on"])
    xg = float(metrics[f"{prefix}_xg"])
    base_name = _short_team_name(team)
    rows = [
        ("Finalizador", heat + shots * 4 + int(xg * 6)),
        ("Armador", heat + danger // 3),
        ("Ponta", heat + int(metrics[f"{prefix}_attacks"] / 7)),
        ("Volante", max(15, heat - 12 + metrics[f"{prefix}_yellow_cards"] * 5)),
    ]
    return [
        {"name": f"{base_name} {role}", "heat": max(0, min(100, value))}
        for role, value in rows
    ]


def _player_table(team: str, rows: list[dict[str, Any]]) -> str:
    body = []
    for row in sorted(rows, key=lambda item: item["heat"], reverse=True):
        body.append(
            "<tr>"
            f"<td>{_esc(row['name'])}</td>"
            f"<td>{_esc(row['heat'])}/100</td>"
            f"<td><div class='stat-bar'><span style='width:{_esc(row['heat'])}%'></span></div></td>"
            "</tr>"
        )
    return (
        f"<h2>{_esc(team)}</h2>"
        "<table><thead><tr><th>Perfil</th><th>Term.</th><th>Pressao</th></tr></thead>"
        f"<tbody>{''.join(body)}</tbody></table>"
    )


def _formation_box(team: str, shape: str, heat: int) -> str:
    return (
        "<div class='stat-line'>"
        f"<strong>{_esc(team)}</strong>"
        f"<div class='muted'>Formacao estimada: {shape}</div>"
        f"<div>Intensidade: {heat}/100</div>"
        f"<div class='stat-bar'><span style='width:{max(0, min(100, int(heat)))}%'></span></div>"
        "</div>"
    )


def _short_team_name(team: str) -> str:
    parts = [part for part in team.split() if part]
    if not parts:
        return "Time"
    return parts[0][:10]


def _possession_share(left: int, right: int) -> int:
    total = max(1, left + right)
    return max(0, min(100, int((left / total) * 100)))


def _safe_int(value: Any) -> int:
    try:
        return int(float(value or 0))
    except (TypeError, ValueError):
        return 0


def _safe_dom_id(value: Any) -> str:
    text = re.sub(r"[^a-zA-Z0-9_-]+", "-", str(value or "match")).strip("-")
    return text[:60] or "match"


def _action_weight(action: Any) -> int:
    text = str(action or "").upper()
    if text == "ENTRAR":
        return 4
    if text == "AGUARDAR":
        return 3
    if text == "SEGURAR":
        return 2
    if text == "SAIR":
        return 1
    return 0


def _action_class(action: Any) -> str:
    action = str(action or "").upper()
    if action == "ENTRAR":
        return "win"
    if action == "SAIR":
        return "loss"
    return "open"


def _scanner_status(state) -> dict[str, Any]:
    candidates = len(state.candidate_signals or [])
    has_active = bool(state.active_signal)
    return {
        "mode": "5 min com jogo ativo" if has_active else "30 min aguardando escolha",
        "last_scan": _short_datetime(state.last_scan_at),
        "candidates": candidates,
        "today_games": len(state.last_games or []),
        "status": "monitorando entrada" if has_active else "scanner livre",
    }


def _supabase_info(settings) -> dict[str, Any]:
    fallback = {
        "status": "nao configurado",
        "games": "-",
        "signals": "-",
        "memory": "-",
    }
    if not settings.supabase_url or not settings.supabase_service_role_key:
        return fallback
    headers = {
        "apikey": settings.supabase_service_role_key,
        "Authorization": f"Bearer {settings.supabase_service_role_key}",
        "Prefer": "count=exact",
    }
    tables = {
        "games": "betsignal_games",
        "signals": "betsignal_signals",
        "memory": "betsignal_ai_memory",
    }
    result = {"status": "online", "games": "-", "signals": "-", "memory": "-"}
    try:
        with httpx.Client(timeout=5) as client:
            for key, table in tables.items():
                response = client.get(
                    f"{settings.supabase_url}/rest/v1/{table}",
                    headers=headers,
                    params={"select": "*", "limit": "1"},
                )
                if response.status_code not in {200, 206}:
                    result["status"] = f"erro {response.status_code}"
                    continue
                content_range = response.headers.get("content-range", "")
                result[key] = content_range.rsplit("/", 1)[-1] if "/" in content_range else "ok"
    except Exception:
        result["status"] = "indisponivel"
    return result


def _short_datetime(value: Any) -> str:
    if not value:
        return "-"
    return str(value).replace("T", " ")[:16]


def _equity_curve(backtest: dict[str, Any]) -> str:
    points = backtest.get("last_equity_units") or []
    if not points:
        return "<p class='muted'>Aguardando historico fechado para desenhar a curva.</p>"
    max_abs = max(abs(float(point)) for point in points) or 1
    bars = []
    for point in points[-12:]:
        value = float(point)
        height = max(8, int((abs(value) / max_abs) * 62))
        klass = "bar neg" if value < 0 else "bar"
        bars.append(f"<span class='{klass}' style='height:{height}px' title='{_esc(value)}u'></span>")
    return "<div class='sparkline'>" + "".join(bars) + "</div>"


def _row(item: dict[str, Any]) -> str:
    game = item.get("game", {})
    outcome = item.get("outcome", "open")
    match = f"{game.get('home', '-')} x {game.get('away', '-')}"
    entry = _entry_summary(item)
    signal_id = _js_string(item.get("signal_id") or "")
    value = item.get("entry_value")
    odds = item.get("entry_odds") or item.get("target_odds")
    profit = item.get("profit_value")
    real_value = _real_value_summary(item)
    return (
        "<tr>"
        f"<td data-label='Data'>{_esc((item.get('created_at') or '')[:16])}</td>"
        f"<td data-label='Jogo'>{_esc(match)}</td>"
        f"<td data-label='Liga'>{_esc(game.get('league', '-'))}</td>"
        f"<td data-label='Entrada'>{entry}</td>"
        f"<td data-label='Valor real'>{real_value}</td>"
        f"<td data-label='Conf.'>{_esc(item.get('confidence', '-'))}%</td>"
        f"<td data-label='Edge' class='{_value_class(item.get('value_edge'), multiplier=100)}'>{_edge(item.get('value_edge'))}</td>"
        f"<td data-label='Stake'>{_esc(item.get('stake_units', 0))}u</td>"
        f"<td data-label='Resultado' class='{_esc(outcome)}'>{_label(outcome)}</td>"
        "<td data-label='Acao'>"
        "<div class='action-buttons'>"
        f"<button class='ghost' type='button' title='Editar valor real' onclick=\"editHistoryValue('{signal_id}', '{_js_string(value or '')}', '{_js_string(odds or '')}', '{_js_string(profit or '')}')\">✎ Editar</button>"
        f"<button class='ghost danger' type='button' title='Excluir registro' onclick=\"deleteHistoryRecord('{signal_id}')\">× Excluir</button>"
        "</div>"
        "</td>"
        "</tr>"
    )


def _active_entries(
    history: list[dict[str, Any]],
    active_signal: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in [active_signal, *history]:
        if not isinstance(item, dict):
            continue
        signal_id = str(item.get("signal_id") or "")
        if signal_id in seen:
            continue
        if item.get("entered") and item.get("outcome") == "open":
            entries.append(item)
            seen.add(signal_id)
    return entries


def _active_entry_row(item: dict[str, Any]) -> str:
    game = item.get("game", {})
    match = f"{game.get('home', '-')} x {game.get('away', '-')}"
    market = item.get("entry_market") or item.get("market") or "-"
    selection = item.get("entry_selection")
    line = item.get("entry_line")
    if selection:
        market = f"{market} - {selection}"
    if line:
        market = f"{market} {line}"
    value = item.get("entry_value")
    odds = item.get("entry_odds") or item.get("target_odds")
    signal_id = _js_string(item.get("signal_id") or "")
    return (
        "<tr>"
        f"<td data-label='Entrada'>{_esc((item.get('entered_at') or item.get('created_at') or '')[:16])}</td>"
        f"<td data-label='Jogo'>{_esc(match)}</td>"
        f"<td data-label='Mercado'>{_esc(market)}</td>"
        f"<td data-label='Valor'>{_esc(value if value is not None else item.get('stake_value', '-'))}</td>"
        f"<td data-label='Odd'>{_esc(odds or '-')}</td>"
        "<td data-label='Acao'>"
        "<div class='action-buttons'>"
        f"<button class='ghost' type='button' title='Informar valor da entrada' onclick=\"editHistoryValue('{signal_id}', '{_js_string(value or '')}', '{_js_string(odds or '')}', '')\">✎ Valor</button>"
        f"<button class='ghost success' type='button' title='Marcar Green' onclick=\"closeEntry('{signal_id}', 'win')\">Green</button>"
        f"<button class='ghost danger' type='button' title='Marcar Red' onclick=\"closeEntry('{signal_id}', 'loss')\">Red</button>"
        "</div>"
        "</td>"
        "</tr>"
    )


def _active(signal: dict[str, Any] | None) -> str:
    if not signal:
        return "<p class='subtle'>Nenhum jogo ativo no momento.</p>"
    game = signal.get("game", {})
    entry = _entry_summary(signal)
    edge = _edge(signal.get("value_edge"))
    edge_class = _value_class(signal.get("value_edge"), multiplier=100)
    score = signal.get("entry_score", "-")
    grade = signal.get("grade", "-")
    risk = signal.get("risk_score", "-")
    return (
        f"<div class='active-title'>{_esc(game.get('home'))} {_esc(game.get('home_goals', 0))} x "
        f"{_esc(game.get('away_goals', 0))} {_esc(game.get('away'))}</div>"
        f"<div class='muted'>{_esc(game.get('league', '-'))} | minuto {_esc(game.get('minute', '-'))}</div>"
        "<div class='active-line'>"
        f"<div class='mini'><div class='muted'>Acao</div><strong>{_esc(signal.get('action'))}</strong></div>"
        f"<div class='mini'><div class='muted'>Score IA</div><strong>{_esc(score)}/100 | {_esc(grade)}</strong></div>"
        f"<div class='mini'><div class='muted'>Risco</div><strong>{_esc(risk)}/100</strong></div>"
        f"<div class='mini'><div class='muted'>Confianca</div><strong>{_esc(signal.get('confidence'))}%</strong></div>"
        f"<div class='mini'><div class='muted'>Edge</div><strong class='{edge_class}'>{edge}</strong></div>"
        f"<div class='mini'><div class='muted'>Entrada</div>{entry}</div>"
        f"<div class='mini'><div class='muted'>Stake</div><strong>{_esc(signal.get('stake_value', 0))} / {_esc(signal.get('stake_units', 0))}u</strong></div>"
        f"<div class='mini'><div class='muted'>Dados</div><strong>{_esc(signal.get('data_quality', '-'))}%</strong></div>"
        "</div>"
        f"<p class='subtle'>{_esc(signal.get('reason'))}</p>"
    )


def _rankings(learning: dict[str, Any]) -> str:
    blocks = []
    for title, key in (
        ("Ligas", "by_league"),
        ("Times", "by_team"),
        ("Mercados", "by_market"),
    ):
        rows = learning.get(key) or []
        if not rows:
            blocks.append(f"<p class='muted'>{title}: aguardando historico fechado.</p>")
            continue
        items = []
        for row in rows[:5]:
            items.append(
                "<tr>"
                f"<td>{_esc(row.get('name'))}</td>"
                f"<td>{_esc(row.get('hit_rate'))}%</td>"
                f"<td class='{_value_class(row.get('profit_units'))}'>{_esc(row.get('profit_units'))}u</td>"
                f"<td>{_esc(row.get('total'))}</td>"
                "</tr>"
            )
        blocks.append(
            f"<h2>{title}</h2>"
            "<table><thead><tr><th>Nome</th><th>Acerto</th><th>Lucro</th><th>Sinais</th></tr></thead>"
            f"<tbody>{''.join(items)}</tbody></table>"
        )
    return "".join(blocks)


def _fast_learning_panel(fast: dict[str, Any]) -> str:
    recent_5 = fast.get("recent_5") or {}
    recent_10 = fast.get("recent_10") or {}
    blocks = [
        "<div class='active-line'>"
        f"<div class='mini'><div class='muted'>Modo</div><strong>{_esc(fast.get('mode', 'neutro'))}</strong></div>"
        f"<div class='mini'><div class='muted'>Momentum</div><strong>{_esc(fast.get('momentum_score', 50))}/100</strong></div>"
        f"<div class='mini'><div class='muted'>Ultimos 5</div><strong>{_esc(recent_5.get('wins', 0))}G / {_esc(recent_5.get('losses', 0))}R</strong></div>"
        f"<div class='mini'><div class='muted'>Ultimos 10</div><strong>{_esc(recent_10.get('wins', 0))}G / {_esc(recent_10.get('losses', 0))}R</strong></div>"
        "</div>"
    ]
    for title, key in (
        ("Mercados quentes", "hot_markets"),
        ("Mercados frios", "cold_markets"),
        ("Times frios", "cold_teams"),
    ):
        rows = fast.get(key) or []
        if not rows:
            blocks.append(f"<p class='muted'>{title}: aguardando mais resultados.</p>")
            continue
        body = []
        for row in rows[:4]:
            body.append(
                "<tr>"
                f"<td>{_esc(row.get('name'))}</td>"
                f"<td>{_esc(row.get('wins'))}G / {_esc(row.get('losses'))}R</td>"
                f"<td class='{_value_class(row.get('profit_units'))}'>{_esc(row.get('profit_units'))}u</td>"
                f"<td>{_esc(row.get('confidence'))}</td>"
                "</tr>"
            )
        blocks.append(
            f"<h2>{title}</h2>"
            "<table><thead><tr><th>Nome</th><th>Forma</th><th>Lucro</th><th>Conf.</th></tr></thead>"
            f"<tbody>{''.join(body)}</tbody></table>"
        )
    return "".join(blocks)


def _source_catalog_panel() -> str:
    rows = []
    for source in FOOTBALL_DATA_SOURCES[:8]:
        rows.append(
            "<tr>"
            f"<td><a href='{_esc(source['url'])}' target='_blank' rel='noopener'>{_esc(source['name'])}</a></td>"
            f"<td>{_esc(source['role'])}</td>"
            f"<td>{_esc(source['tier'])}</td>"
            f"<td>{_esc(source['integration'])}</td>"
            "</tr>"
        )
    return (
        "<p class='muted'>Prioridade: API/CSV estavel primeiro; scraping de casa de aposta fica fora do caminho principal.</p>"
        "<table><thead><tr><th>Fonte</th><th>Uso</th><th>Tipo</th><th>Status</th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table>"
    )


def _commercial_panel(settings) -> str:
    website = _esc(settings.website_url or "-")
    whatsapp = _esc(settings.sales_whatsapp or "-")
    email = _esc(settings.sales_email or "-")
    starter = _esc(f"R$ {settings.plan_starter_price_brl:.0f}/mes")
    pro = _esc(f"R$ {settings.plan_pro_price_brl:.0f}/mes")
    team = _esc(f"R$ {settings.plan_team_price_brl:.0f}/mes")
    return (
        "<div class='active-line'>"
        "<div class='mini'><div class='muted'>Produto</div>"
        f"<strong>{_esc(settings.product_name)}</strong><div class='muted'>{_esc(settings.product_tagline)}</div></div>"
        f"<div class='mini'><div class='muted'>Starter</div><strong>{starter}</strong><div class='muted'>scanner + telegram + dashboard</div></div>"
        f"<div class='mini'><div class='muted'>Pro</div><strong>{pro}</strong><div class='muted'>tudo do starter + memoria IA + suporte</div></div>"
        f"<div class='mini'><div class='muted'>Team</div><strong>{team}</strong><div class='muted'>multi-operador + operacao guiada</div></div>"
        f"<div class='mini'><div class='muted'>Site</div><strong>{website}</strong></div>"
        f"<div class='mini'><div class='muted'>WhatsApp</div><strong>{whatsapp}</strong></div>"
        f"<div class='mini'><div class='muted'>Email</div><strong>{email}</strong></div>"
        "</div>"
        "<p class='muted'>Dor resolvida: excesso de ruido, entrada sem criterio e falta de disciplina operacional. "
        "Oferta focada em decisao clara, rotina e controle de risco.</p>"
    )


def _best_name(rows: Any) -> str:
    if not rows:
        return "-"
    name = str(rows[0].get("name", "-"))
    return _esc(name[:14])


def _advice(history: list[dict[str, Any]]) -> str:
    settled = [item for item in history if item.get("outcome") in {"win", "loss"}]
    if len(settled) < 5:
        return "Ainda ha poucos resultados marcados. Marque green/red no Telegram para a IA estatistica aprender quais ligas, minutos e niveis de confianca funcionam melhor."

    by_league: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in settled:
        league = item.get("game", {}).get("league", "Sem liga")
        by_league[league].append(item)

    ranked = []
    for league, items in by_league.items():
        if len(items) < 2:
            continue
        wins = sum(1 for item in items if item.get("outcome") == "win")
        ranked.append((wins / len(items), league, len(items)))
    if not ranked:
        return "Continue acumulando historico. A recomendacao fica mais forte quando cada liga tiver pelo menos 2 sinais finalizados."
    ranked.sort(reverse=True)
    rate, league, count = ranked[0]
    return f"Melhor recorte ate agora: {league}, com {round(rate * 100, 1)}% de acerto em {count} sinais. Priorize entradas parecidas e reduza stake em ligas sem historico."


def _label(outcome: str) -> str:
    return {"win": "Green", "loss": "Red", "void": "Anulada", "open": "Aberta"}.get(
        outcome, outcome
    )


def _esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def _edge(value: Any) -> str:
    if value is None:
        return "-"
    try:
        return f"{round(float(value) * 100, 1)}%"
    except (TypeError, ValueError):
        return "-"


def _value_class(value: Any, multiplier: int = 1) -> str:
    try:
        numeric = float(value) * multiplier
    except (TypeError, ValueError):
        return "flat"
    if numeric > 0:
        return "pos"
    if numeric < 0:
        return "neg"
    return "flat"


def _entry_summary(item: dict[str, Any]) -> str:
    market = item.get("entry_market") or item.get("market") or item.get("action", "-")
    selection = item.get("entry_selection")
    line = item.get("entry_line")
    value = item.get("entry_value")
    odds = item.get("entry_odds") or item.get("target_odds")
    detail = []
    if selection:
        detail.append(f"seleção {_esc(selection)}")
    if line:
        detail.append(f"linha {_esc(line)}")
    if odds:
        detail.append(f"odd {_esc(odds)}")
    if value:
        detail.append(f"valor {_esc(value)}")
    if detail:
        return f"<strong>{_esc(market)}</strong><br><span class='muted'>{' | '.join(detail)}</span>"
    return f"<strong>{_esc(market)}</strong>"


def _real_value_summary(item: dict[str, Any]) -> str:
    value = item.get("entry_value")
    odds = item.get("entry_odds") or item.get("target_odds")
    profit = item.get("profit_value")
    parts = []
    if value is not None:
        parts.append(f"R$ {_esc(value)}")
    if odds:
        parts.append(f"odd {_esc(odds)}")
    if profit is not None:
        parts.append(f"lucro R$ {_esc(profit)}")
    if parts:
        return "<br>".join(parts)
    return "<span class='muted'>clique em editar</span>"


def _js_string(value: Any) -> str:
    return (
        str(value if value is not None else "")
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\n", " ")
        .replace("\r", " ")
    )


def _domains(raw: str) -> str:
    links = []
    for item in raw.split(","):
        url = item.strip()
        if not url:
            continue
        links.append(f"<a href='{_esc(url)}'>{_esc(url)}</a>")
    return " ".join(links)
