from dataclasses import dataclass
import os

from dotenv import load_dotenv


def _as_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _as_confidence(value: str | None, default: int = 62) -> int:
    if value is None or not value.strip():
        return default
    number = float(value)
    if 0 < number <= 1:
        number *= 100
    return max(0, min(100, int(round(number))))


@dataclass(frozen=True)
class Settings:
    product_name: str
    product_tagline: str
    website_url: str
    sales_whatsapp: str
    sales_email: str
    plan_starter_price_brl: float
    plan_pro_price_brl: float
    plan_team_price_brl: float
    telegram_bot_token: str
    scan_interval_seconds: int
    idle_scan_interval_seconds: int
    active_scan_interval_seconds: int
    test_mode: bool
    api_football_key: str | None
    api_football_base_url: str
    gemini_api_key: str | None
    gemini_model: str
    state_file: str
    min_confidence: int
    bankroll: float
    unit_percent: float
    max_stake_units: float
    min_history_for_enter: int
    min_edge_to_enter: float
    kelly_fraction: float
    daily_red_limit: int
    block_esports: bool
    dashboard_user: str
    dashboard_password: str
    dashboard_domains: str
    support_note: str
    supabase_url: str | None
    supabase_service_role_key: str | None


def load_settings() -> Settings:
    load_dotenv()
    return Settings(
        product_name=os.getenv("PRODUCT_NAME", "BetSignal Cloud").strip() or "BetSignal Cloud",
        product_tagline=os.getenv(
            "PRODUCT_TAGLINE",
            "Sinais ao vivo com risco controlado, operacao assistida e clareza de entrada.",
        ).strip(),
        website_url=os.getenv("WEBSITE_URL", "https://novo.tickpost.com.br").strip(),
        sales_whatsapp=os.getenv("SALES_WHATSAPP", "").strip(),
        sales_email=os.getenv("SALES_EMAIL", "").strip(),
        plan_starter_price_brl=float(os.getenv("PLAN_STARTER_PRICE_BRL", "97")),
        plan_pro_price_brl=float(os.getenv("PLAN_PRO_PRICE_BRL", "197")),
        plan_team_price_brl=float(os.getenv("PLAN_TEAM_PRICE_BRL", "497")),
        telegram_bot_token=os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
        scan_interval_seconds=int(os.getenv("SCAN_INTERVAL_SECONDS", "300")),
        idle_scan_interval_seconds=int(os.getenv("IDLE_SCAN_INTERVAL_SECONDS", "1800")),
        active_scan_interval_seconds=int(os.getenv("ACTIVE_SCAN_INTERVAL_SECONDS", "300")),
        test_mode=_as_bool(os.getenv("TEST_MODE"), False),
        api_football_key=os.getenv("API_FOOTBALL_KEY") or None,
        api_football_base_url=os.getenv(
            "API_FOOTBALL_BASE_URL", "https://v3.football.api-sports.io"
        ).rstrip("/"),
        gemini_api_key=os.getenv("GEMINI_API_KEY") or None,
        gemini_model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        state_file=os.getenv("STATE_FILE", "data/state.json"),
        min_confidence=_as_confidence(os.getenv("MIN_CONFIDENCE"), 62),
        bankroll=float(os.getenv("BANKROLL", "1000")),
        unit_percent=float(os.getenv("UNIT_PERCENT", "1")),
        max_stake_units=float(os.getenv("MAX_STAKE_UNITS", "2")),
        min_history_for_enter=int(os.getenv("MIN_HISTORY_FOR_ENTER", "30")),
        min_edge_to_enter=float(os.getenv("MIN_EDGE_TO_ENTER", "0.05")),
        kelly_fraction=float(os.getenv("KELLY_FRACTION", "0.25")),
        daily_red_limit=int(os.getenv("DAILY_RED_LIMIT", "2")),
        block_esports=_as_bool(os.getenv("BLOCK_ESPORTS"), True),
        dashboard_user=os.getenv("DASHBOARD_USER", "admin"),
        dashboard_password=os.getenv("DASHBOARD_PASSWORD", "change-me-now"),
        dashboard_domains=os.getenv(
            "DASHBOARD_DOMAINS",
            "http://2.24.217.214,http://novo.tickpost.com.br",
        ),
        support_note=os.getenv(
            "SUPPORT_NOTE",
            "Se der problema, envie /suporte no Telegram e compartilhe o diagnostico comigo no Codex.",
        ),
        supabase_url=(os.getenv("SUPABASE_URL") or "").rstrip("/") or None,
        supabase_service_role_key=os.getenv("SUPABASE_SERVICE_ROLE_KEY") or None,
    )
