# BetSignal Cloud

Robo Telegram para sinais de futebol ao vivo, com modo teste sem API paga,
API-Football opcional, Gemini opcional, controle de jogo ativo e persistencia
em `data/state.json`.

## Comandos

- `/start` abre o menu.
- `/scan` procura jogos ao vivo agora.
- `/status` mostra o jogo ativo e o proximo scan.
- `/stop` libera o jogo ativo e permite novo scan.
- `/oferta` mostra a oferta comercial e planos.

## Gestao de risco

O bot nao executa apostas automaticamente. Ele envia alerta informativo com
acao, confianca e unidade sugerida para decisao manual.

- `BANKROLL`: banca usada para calcular a unidade.
- `UNIT_PERCENT`: tamanho de 1 unidade em percentual da banca.
- `MAX_STAKE_UNITS`: limite de unidades por sinal.
- `MIN_HISTORY_FOR_ENTER`: amostra minima antes de permitir `ENTRAR`.
- `MIN_EDGE_TO_ENTER`: edge minimo para entrada.
- `KELLY_FRACTION`: fracao conservadora do Kelly para stake.
- `DAILY_RED_LIMIT`: trava operacional por reds no ciclo atual.

Quando o limite de reds e atingido, o sistema pausa novos sinais e retorna
apenas as 06:00 (America/Sao_Paulo).

## Produto vendavel

Voce pode configurar nome comercial, canais de venda e planos no `.env`:

- `PRODUCT_NAME`
- `PRODUCT_TAGLINE`
- `WEBSITE_URL`
- `SALES_WHATSAPP`
- `SALES_EMAIL`
- `PLAN_STARTER_PRICE_BRL`
- `PLAN_PRO_PRICE_BRL`
- `PLAN_TEAM_PRICE_BRL`

Materiais de comercializacao no repositorio:

- `PRODUCT_OFFER_BR.md`
- `SALES_PLAYBOOK_BR.md`
- `LAUNCH_30_DIAS_BR.md`

## Rodar localmente

```bash
cp .env.example .env
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python -m src.main
```

## Rodar com Docker

```bash
cp .env.example .env
docker compose up -d --build
docker compose logs -f betsignal
```

## Dashboard

O servico `dashboard` abre a porta 80 e mostra historico, greens, reds,
taxa de acerto e leitura estatistica para os proximos jogos.

```bash
docker compose logs -f dashboard
```

Configure `DASHBOARD_USER` e `DASHBOARD_PASSWORD` no `.env`.
Use `DASHBOARD_DOMAINS` para listar os acessos mostrados na dashboard e no
Telegram.

Comandos uteis no Telegram:

- `/dashboard` mostra os links.
- `/stats` mostra eficiencia e aprendizado.
- `/suporte` gera diagnostico para compartilhar no Codex.

Preencha `TELEGRAM_BOT_TOKEN` no `.env` para o bot conectar ao Telegram.
Preencha `API_FOOTBALL_KEY` para jogos ao vivo reais e odds ao vivo via
API-Football. Sem essa chave, o bot usa o provider publico da ESPN como
fallback real para placares, estatisticas e odds quando disponiveis. Use
`TEST_MODE=true` somente quando quiser dados mockados.
